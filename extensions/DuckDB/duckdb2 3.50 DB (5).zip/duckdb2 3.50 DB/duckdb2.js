define([
  "qlik",
  "jquery",
  "./lib/Arrow.es2015.min",  // Local Arrow file
  "./lib/duckdb-browser-v2"   // Local DuckDB wrapper
], function (qlik, $, Arrow, duckdb) {
  "use strict";

  window.Arrow = Arrow || {};
  let dbInstance = null;
  let connInstance = null;
  let offset = 0;
  let cube = null;
  let totalCount = 0;
  let currentFilter = "";
  let lastCustomSQL = "";
  let pivotFields = [];
  let sortField = null;
  let sortDirection = "asc";
  let isInitialized = false;
  let availableFields = [];
  let fileTables = [];
  let skippedFiles = [];
  let lastFetchedData = null;
  let lastLayoutHash = null;
  let lastCubeDataHash = null;
  let justRefreshed = false; // New: Flag to indicate a recent refresh

  const extensionConfig = {
    copyright: {
      tribute: "This Qlik Extension is shared in memory of Stuart Wannop",
      description: "A Qlik Champion who would have enjoyed sharing this type of embedded object",
      year: "2025",
      dependencies: [
        { name: "DuckDB WASM", url: "https://duckdb.org/" },
        { name: "Apache Arrow", url: "https://arrow.apache.org/" }
      ],
      disclaimer: "Use of this extension is entirely at your own risk; no warranties are implied or inferred"
    }
  };

  function withTimeout(promise, timeoutMs, errorMessage = "Query timed out") {
    const timeout = new Promise((_, reject) => {
      setTimeout(() => reject(new Error(errorMessage)), timeoutMs);
    });
    return Promise.race([promise, timeout]);
  }

  async function initDuckDB(layout) {
    if (isInitialized && connInstance) return connInstance;

    if (dbInstance) {
      try {
        if (connInstance) {
          await connInstance.close();
          console.log("Previous connInstance closed");
        } else {
          console.warn("No connInstance to close");
        }
        await dbInstance.terminate();
        console.log("Previous dbInstance terminated");
      } catch (error) {
        console.error("Error during cleanup:", error);
      }
      dbInstance = null;
      connInstance = null;
    }

    const DUCKDB_URL = layout.duckdbWasmUrl.startsWith("https://") ? layout.duckdbWasmUrl : `https://${layout.duckdbWasmUrl}`;
    const WORKER_URL = layout.duckdbWorkerUrl.startsWith("https://") ? layout.duckdbWorkerUrl : `https://${layout.duckdbWorkerUrl}`;
    const ARROW_URL = layout.arrowUrl.startsWith("https://") ? layout.arrowUrl : `https://${layout.arrowUrl}`;

    if (!DUCKDB_URL || !WORKER_URL || !ARROW_URL || 
        !DUCKDB_URL.startsWith("https://") || !WORKER_URL.startsWith("https://") || !ARROW_URL.startsWith("https://")) {
      throw new Error("MISSING_DEPENDENCIES");
    }

    try {
      console.log("Initializing DuckDB with URLs:", { DUCKDB_URL, WORKER_URL, ARROW_URL });
      const worker = await duckdb.createWorker(DUCKDB_URL, WORKER_URL, ARROW_URL);
      dbInstance = new duckdb.AsyncDuckDB(new duckdb.ConsoleLogger(), worker);
      await dbInstance.instantiate(DUCKDB_URL);
      connInstance = await dbInstance.connect();
      if (!connInstance) throw new Error("Failed to establish DuckDB connection");

      const maxRam = layout.maxRam || 4;
      await connInstance.query(`SET memory_limit = '${maxRam}GB';`);

      const files = layout.dataFiles || [{ url: layout.parquetUrl, type: "parquet" }];
      if (!files.length || !files[0].url) throw new Error("NO_FILES_SELECTED");

      for (const file of files) {
        const url = file.url.toLowerCase();
        const declaredType = file.type?.toLowerCase() || "parquet";
        const inferredType = url.endsWith(".csv") ? "csv" : url.endsWith(".parquet") ? "parquet" : url.endsWith(".json") ? "json" : url.endsWith(".arrow") ? "arrow" : "unknown";
        if (inferredType !== "unknown" && inferredType !== declaredType) {
          throw new Error(`FILE_TYPE_MISMATCH: ${file.url} (declared as ${declaredType}, appears to be ${inferredType})`);
        }
      }

      totalCount = 0;
      const timeoutMs = layout.queryTimeout || 60000;
      fileTables = [];
      skippedFiles = [];
      const maxRamBytes = maxRam * 1024 * 1024 * 1024;
      const debug = layout.debug || false;

      if (debug) console.time("Total load time");

      const filePromises = files.map(async (file, i) => {
        const fileName = file.name || `file_${i}.${file.type}`;
        if (debug) console.time(`HEAD ${fileName}`);
        const headResponse = await fetch(file.url, { method: 'HEAD' });
        if (!headResponse.ok) {
          skippedFiles.push({ name: file.url, size: 'Unknown (HEAD failed)' });
          if (debug) console.timeEnd(`HEAD ${fileName}`);
          return null;
        }
        const sizeBytes = headResponse.headers.get('Content-Length') ? parseInt(headResponse.headers.get('Content-Length')) : null;
        const sizeMB = sizeBytes ? (sizeBytes / (1024 * 1024)).toFixed(1) : 'Unknown';
        if (debug) console.timeEnd(`HEAD ${fileName}`);

        let proceed = true;
        if (sizeBytes && sizeBytes > maxRamBytes) {
          proceed = confirm(`File size (${sizeMB} MB) exceeds RAM limit (${maxRam} GB). Continue loading ${file.url}?`);
          if (!proceed) {
            skippedFiles.push({ name: file.url, size: sizeMB });
            return null;
          }
        }

        if (debug) console.time(`Fetch ${fileName}`);
        const fetchResponse = await fetch(file.url);
        if (!fetchResponse.ok) throw new Error(`FETCH_FAILED: ${file.url}`);
        const buffer = await fetchResponse.arrayBuffer();
        if (debug) console.timeEnd(`Fetch ${fileName}`);

        if (debug) console.time(`Register ${fileName}`);
        await dbInstance.registerFileBuffer(fileName, new Uint8Array(buffer));
        if (debug) console.timeEnd(`Register ${fileName}`);

        let createQuery;
        if (file.type === "csv") {
          createQuery = `CREATE OR REMOVE TABLE data_${i} AS SELECT * FROM read_csv_auto('${fileName}', sample_size=10000)`;
        } else if (file.type === "json") {
          createQuery = `CREATE OR REPLACE TABLE data_${i} AS SELECT * FROM read_json_auto('${fileName}')`;
        } else if (file.type === "arrow") {
          createQuery = `CREATE OR REPLACE TABLE data_${i} AS SELECT * FROM read_parquet('${fileName}')`;
        } else {
          createQuery = `CREATE OR REPLACE TABLE data_${i} AS SELECT * FROM '${fileName}'`;
        }
        if (debug) console.time(`Create table ${fileName}`);
        await withTimeout(connInstance.query(createQuery), timeoutMs, `${file.type.toUpperCase()} load timeout for ${fileName}`);
        if (debug) console.timeEnd(`Create table ${fileName}`);

        if (debug) console.time(`Count ${fileName}`);
        const countResult = await withTimeout(connInstance.query(`SELECT COUNT(*) as count FROM data_${i}`), timeoutMs);
        const fileCount = Number(countResult.toArray()[0].count);
        totalCount += fileCount;
        if (debug) console.timeEnd(`Count ${fileName}`);

        fileTables.push(`data_${i}`);
        return fileCount;
      });

      const validFiles = (await Promise.all(filePromises)).filter(count => count !== null);
      if (validFiles.length === 0) throw new Error("NO_VALID_FILES_LOADED");

      if (debug) console.time("Create all_data view");
      const unionQuery = fileTables.length === 1
        ? `CREATE OR REPLACE VIEW all_data AS SELECT * FROM ${fileTables[0]}`
        : `CREATE OR REPLACE VIEW all_data AS ${fileTables.map(t => `SELECT * FROM ${t}`).join(" UNION ALL ")}`;
      await withTimeout(connInstance.query(unionQuery), timeoutMs, "Failed to create all_data view");
      if (debug) console.timeEnd("Create all_data view");
      if (debug) console.timeEnd("Total load time");

      if (debug) console.time("Aggregate available fields");
      const allFields = new Set();
      for (const table of fileTables) {
        const fieldsResult = await connInstance.query(`DESCRIBE ${table}`);
        fieldsResult.toArray().forEach(row => allFields.add(row.column_name));
      }
      availableFields = Array.from(allFields);
      if (debug) console.timeEnd("Aggregate available fields");

      isInitialized = true;
      return connInstance;
    } catch (error) {
      console.error("DuckDB initialization failed:", error);
      dbInstance = null;
      connInstance = null;
      throw error;
    }
  }

  async function fetchPage(offset, limit, manualFilter, fieldMappings, cubeData, layout, sortField = null, sortDirection = "asc") {
    if (!connInstance) await initDuckDB(layout);
    const timeoutMs = layout.queryTimeout || 60000;
    const baseQuery = "SELECT * FROM all_data";
    let query = baseQuery;

    const activePivotFields = pivotFields.filter(Boolean);
    if (activePivotFields.length > 0) {
      if (activePivotFields.length === 1) {
        query = `SELECT ${activePivotFields[0]}, COUNT(*) as count FROM (${baseQuery}) AS tmp`;
      } else {
        let cteParts = [];
        let selectParts = [];
        let joinParts = [];
        let orderParts = [];
        
        for (let i = 0; i < activePivotFields.length; i++) {
          const fieldsUpToI = activePivotFields.slice(0, i + 1);
          cteParts.push(`
            level${i + 1} AS (
              SELECT ${fieldsUpToI.join(", ")}, COUNT(*) as count${i + 1}
              FROM (${baseQuery}) AS tmp
              GROUP BY ${fieldsUpToI.join(", ")}
            )`);
          selectParts.push(`l${i + 1}.${activePivotFields[i]} AS field${i + 1}, l${i + 1}.count${i + 1}`);
          if (i > 0) {
            joinParts.push(`LEFT JOIN level${i + 1} l${i + 1} ON ${fieldsUpToI.slice(0, i).map(f => `l${i}.${f} = l${i + 1}.${f}`).join(" AND ")}`);
          }
          orderParts.push(`l${i + 1}.${activePivotFields[i]}`);
        }

        query = `
          WITH ${cteParts.join(", ")}
          SELECT ${selectParts.join(", ")}
          FROM level1 l1
          ${joinParts.join("\n")}
          ORDER BY ${orderParts.join(", ")}`;
      }
    }

    let whereClauses = [];
    const hasSelections = cubeData && fieldMappings && fieldMappings.length && Object.keys(cubeData).length > 0 && Object.values(cubeData).some(v => v.selected?.length > 0);

    let matchedCount = 0;
    let unmatchedCount = totalCount;

    if (fieldMappings && fieldMappings.length > 0 && cubeData && Object.keys(cubeData).length > 0) {
      const matchedQueries = fieldMappings.map(mapping => {
        const qlikValues = cubeData[mapping.qlikField]?.all || [];
        if (qlikValues.length) {
          const values = qlikValues.map(val => `'${val.replace(/'/g, "''")}'`).join(",");
          return `SELECT COUNT(*) as count FROM all_data WHERE ${mapping.parquetField} IN (${values})`;
        }
        return null;
      }).filter(Boolean);

      if (matchedQueries.length) {
        const results = await Promise.all(matchedQueries.map(q => withTimeout(connInstance.query(q), timeoutMs)));
        matchedCount = Math.min(...results.map(r => Number(r.toArray()[0].count)));
        unmatchedCount = totalCount - matchedCount;
        console.log("Initial matchedCount:", matchedCount, "unmatchedCount:", unmatchedCount);
      }
    } else {
      console.log("No valid mappings or cubeData, defaulting unmatched to totalCount:", totalCount);
    }

    if (hasSelections) {
      fieldMappings.forEach(mapping => {
        const selectedValues = cubeData[mapping.qlikField]?.selected || [];
        if (selectedValues.length) {
          const values = selectedValues.map(val => `'${val.replace(/'/g, "''")}'`).join(",");
          whereClauses.push(`${mapping.parquetField} IN (${values})`);
        }
      });
    }

    if (manualFilter && fieldMappings && fieldMappings.length) {
      const searchClause = fieldMappings.map(mapping => 
        `${mapping.parquetField} LIKE '%${manualFilter}%'`
      ).join(" OR ");
      whereClauses.push(whereClauses.length ? `(${searchClause})` : searchClause);
    }

    if (whereClauses.length) {
      const whereClause = whereClauses.join(" AND ");
      if (activePivotFields.length > 0) {
        if (activePivotFields.length === 1) {
          query += ` WHERE ${whereClause}`;
        } else {
          query = query.replace(`FROM (${baseQuery}) AS tmp`, `FROM (${baseQuery}) AS tmp WHERE ${whereClause}`);
        }
      } else {
        query += ` WHERE ${whereClause}`;
      }
    }

    if (activePivotFields.length === 1) {
      query += ` GROUP BY ${activePivotFields[0]}`;
    }

    if (sortField && layout.sortScope === "entireTable" && activePivotFields.length === 0) {
      query += ` ORDER BY ${sortField} ${sortDirection}`;
    }
    const maxRows = layout.maxQueryRows || 0;
    if (maxRows > 0 && !query.toUpperCase().includes("LIMIT") && activePivotFields.length === 0) {
      query += ` LIMIT ${maxRows}`;
    } else if (limit > 0 && !query.toUpperCase().includes("LIMIT") && activePivotFields.length === 0) {
      query += ` LIMIT ${limit} OFFSET ${offset}`;
    }

    const dataResult = await withTimeout(connInstance.query(query), timeoutMs);
    const data = dataResult.toArray().map(row => {
      const obj = {};
      for (let key in row) obj[key] = typeof row[key] === "bigint" ? Number(row[key]) : row[key];
      return obj;
    });

    let filteredCount = matchedCount;
    let finalUnmatchedCount = unmatchedCount;

    if (hasSelections || whereClauses.length) {
      const countQuery = `SELECT COUNT(*) as filteredCount FROM (${baseQuery}${whereClauses.length ? " WHERE " + whereClauses.join(" AND ") : ""}) AS tmp`;
      const unmatchedQuery = `SELECT COUNT(*) as unmatchedCount FROM (${baseQuery}${whereClauses.length ? " WHERE " + whereClauses.map(cl => cl.replace(" IN (", " NOT IN (")).join(" OR ") : ""}) AS tmp`;
      const [countResult, unmatchedResult] = await Promise.all([
        withTimeout(connInstance.query(countQuery), timeoutMs),
        withTimeout(connInstance.query(unmatchedQuery), timeoutMs)
      ]);
      filteredCount = Number(countResult.toArray()[0].filteredCount);
      finalUnmatchedCount = Number(unmatchedResult.toArray()[0].unmatchedCount);
      console.log("Selected filteredCount:", filteredCount, "unmatchedCount:", finalUnmatchedCount);
    }

    if (sortField && layout.sortScope !== "entireTable" && activePivotFields.length === 0) {
      data.sort((a, b) => {
        let aVal = a[sortField] ?? ""; let bVal = b[sortField] ?? "";
        if (!isNaN(Number(aVal)) && !isNaN(Number(bVal))) {
          aVal = Number(aVal) || 0; bVal = Number(bVal) || 0;
          return sortDirection === "asc" ? aVal - bVal : bVal - aVal;
        }
        aVal = String(aVal); bVal = String(bVal);
        return sortDirection === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(bVal);
      });
    }

    lastFetchedData = { data, filteredCount, unmatchedCount: finalUnmatchedCount };
    return lastFetchedData;
  }

  async function executeCustomSQL(query, layout) {
    if (!connInstance) await initDuckDB(layout);
    const timeoutMs = layout.queryTimeout || 60000;
    try {
      let finalQuery = query.trim();
      const maxRows = layout.maxQueryRows || 0;
      if (maxRows > 0 && !finalQuery.toUpperCase().includes("LIMIT")) {
        finalQuery += ` LIMIT ${maxRows}`;
      }
      if (!finalQuery.toUpperCase().includes("OFFSET")) {
        finalQuery += ` OFFSET 0`;
      }

      const result = await withTimeout(connInstance.query(finalQuery), timeoutMs);
      return result.toArray().map(row => {
        const obj = {};
        for (let key in row) {
          obj[key] = typeof row[key] === "bigint" ? Number(row[key]) : row[key];
        }
        return obj;
      });
    } catch (error) {
      return [{ error: `SQL Error: ${error.message}` }];
    }
  }

  async function getStatsQuery(col, columnType) {
    if (['DOUBLE', 'FLOAT', 'INTEGER'].includes(columnType)) {
      return `
        WITH summarized AS (
          SELECT 
            COUNT(*) AS count,
            SUM(CASE WHEN "${col}" IS NULL THEN 1 ELSE 0 END) AS null_count,
            COUNT(DISTINCT "${col}") AS unique_count,
            MIN("${col}") AS min,
            MAX("${col}") AS max,
            AVG("${col}") AS mean,
            STDDEV("${col}") AS stddev
          FROM all_data
        ),
        outlier_stats AS (
          SELECT 
            SUM(CASE WHEN "${col}" > (SELECT mean + 2 * stddev FROM summarized) 
                     OR "${col}" < (SELECT mean - 2 * stddev FROM summarized) 
                THEN 1 ELSE 0 END) AS outlier_count
          FROM all_data
        )
        SELECT
          '${col}' AS quality_category,
          count AS total_entries,
          null_count,
          ROUND(100.0 * null_count / count, 2) AS null_percentage,
          unique_count AS unique_values,
          ROUND(100.0 * unique_count / count, 2) AS unique_percentage,
          CONCAT(
            'Min: ', ROUND(min, 2),
            ' | Max: ', ROUND(max, 2),
            ' | Mean: ', ROUND(mean, 2),
            ' | Std Dev: ', ROUND(stddev, 2)
          ) AS type_specific_analysis,
          ROUND(100.0 * outlier_count / count, 2) AS outlier_percentage
        FROM summarized
        LEFT JOIN outlier_stats ON 1=1
      `;
    }
    return `
      WITH stats AS (
        SELECT 
          COUNT(*) AS total_entries,
          SUM(CASE WHEN "${col}" IS NULL THEN 1 ELSE 0 END) AS null_count,
          COUNT(DISTINCT "${col}") AS unique_values
        FROM all_data
      )
      SELECT
        '${col}' AS quality_category,
        total_entries,
        null_count,
        ROUND(100.0 * null_count / total_entries, 2) AS null_percentage,
        unique_values,
        ROUND(100.0 * unique_values / total_entries, 2) AS unique_percentage,
        'Unsupported Type' AS type_specific_analysis,
        NULL AS outlier_percentage
      FROM stats
    `;
  }

  async function executeStatsForColumn(columnName, layout) {
    const typeResult = await executeCustomSQL(`
      SELECT ANY_VALUE(TYPEOF("${columnName}")) AS column_type
      FROM all_data
    `, layout);
    const columnType = typeResult[0].column_type;
    const query = await getStatsQuery(columnName, columnType);
    return await executeCustomSQL(query, layout);
  }

  async function executeStatsForSample(layout) {
    const batchSize = 5;
    const results = [];
    
    for (let i = 0; i < availableFields.length; i += batchSize) {
      const batchFields = availableFields.slice(i, i + batchSize);
      const batchResults = await Promise.all(batchFields.map(async (col, index) => {
        const typeResult = await executeCustomSQL(`
          SELECT ANY_VALUE(TYPEOF("${col}")) AS column_type
          FROM all_data
        `, layout);
        const columnType = typeResult[0].column_type;
        const query = await getStatsQuery(col, columnType);
        console.log(`Executing query ${i + index + 1} for column "${col}":`, query);
        return await executeCustomSQL(query, layout);
      }));
      results.push(...batchResults);
    }

    if (!results || results.length === 0) throw new Error("No valid results generated.");
    return results.flat();
  }

  async function applyThemeStyles(layout) {
    const debug = layout && layout.debug || false;
    const root = document.documentElement;

    root.style.setProperty('--background-color', '#ffffff');
    root.style.setProperty('--text-color', '#000000');
    root.style.setProperty('--header-background', '#f5f5f5');

    if (qlik.theme) {
      try {
        const theme = await qlik.theme.get();
        if (theme) {
          root.style.setProperty('--background-color', theme.background || '#ffffff');
          root.style.setProperty('--text-color', theme.text || '#000000');
          root.style.setProperty('--header-background', theme.headerBackground || '#f5f5f5');
          if (debug) console.log("Qlik Theme applied:", theme.name);
        } else if (debug) {
          console.log("No Qlik Theme defined; using defaults.");
        }
      } catch (e) {
        if (debug) console.log("Theme fetch failed, using defaults:", e.message);
      }
    } else if (debug) {
      console.log("Qlik theme API unavailable; using defaults.");
    }
  }

  async function evaluateExpression(expression) {
    if (!expression || typeof expression !== "string") return expression;
    if (expression.startsWith("=")) {
      try {
        const expr = expression.substring(1); // Remove the '='
        const result = await qlik.currApp().evaluate(expr);
        return result || "Expression Error";
      } catch (error) {
        console.error("Error evaluating expression:", error);
        return "Expression Error";
      }
    }
    return expression;
  }

  async function renderTable($element, data, layout, currentOffset, fieldMappings, cubeData, currentPageSize) {
  console.log("renderTable started, clearing $element");
  $element.empty();

  const pageSize = currentPageSize || layout.pageSize || 25;
  const styles = layout.styles || {};
  const boldFirstPivotCount = layout.styles && layout.styles.boldFirstPivotCount !== false;
  const activePivotFields = pivotFields.filter(Boolean);
  const maxPivot = layout.maxPivot || 3;
  const fileType = (layout.dataFiles?.[0]?.type || "parquet").toUpperCase();

  console.log("Creating table container");
  let container = $("<div>").addClass("table-container").css({ padding: "10px", "background-color": "#fff" });
  $element.append(container);

  if (skippedFiles.length > 0) {
    const warningDiv = $("<div>").addClass("warning").css({
      "margin-bottom": "10px",
      "background-color": "#fff3cd",
      "color": "#856404",
      "padding": "10px",
      "font-weight": "bold"
    }).text(`Warning: Skipped ${skippedFiles.length} ${fileType} file(s) due to size exceeding ${layout.maxRam || 4}GB: ${skippedFiles.map(f => f.name).join(", ")}`);
    container.prepend(warningDiv);
  }
  if (!fieldMappings.length) {
    const mappingWarning = $("<div>").addClass("warning").css({
      "margin-bottom": "10px",
      "background-color": "#fff3cd",
      "color": "#856404",
      "padding": "10px"
    }).text("No Qlik field mappings defined—running as standalone query tool.");
    container.prepend(mappingWarning);
  }

  let kpiDiv = $("<div>").addClass("kpi-div").css({
    "margin-bottom": "10px",
    display: "flex",
    "flex-wrap": "wrap",
    gap: "15px",
    "font-weight": "bold",
    color: "#333",
    "background-color": "#fff"
  }).attr("aria-live", "polite");
  container.append(kpiDiv);

  const kpiItems = [
    { label: "Total Records", value: totalCount },
    { label: "Last Refreshed", value: new Date().toLocaleTimeString() },
    ...(fieldMappings && fieldMappings.length > 0 ? [
      { label: "Matched Records", value: data.filteredCount || 0 },
      { label: "Unmatched Records", value: data.unmatchedCount || 0 }
    ] : [])
  ];
  kpiItems.forEach(item => {
    kpiDiv.append($("<div>").css({ display: "flex", gap: "5px" })
      .append($("<span>").text(`${item.label}:`).css({ "font-weight": "normal" }))
      .append($("<span>").text(item.value)));
  });

  let refreshPending = false;
  let buttonContainer = $("<div>").addClass("button-container").css({ margin: "0 0 10px 0", display: "flex", gap: "10px" });
  container.append(buttonContainer);

  let refreshButton = $("<button>").addClass("refresh-button").text("Refresh Data").attr({
    "aria-label": "Refresh data",
    "role": "button"
  }).css({
    "border": "1px solid black",
    "padding": "2px 6px",
    "cursor": "pointer",
    "background-color": "#fff",
    "color": "#000"
  }).on("click", async () => {
    if (refreshPending) return;
    refreshPending = true;
    try {
      refreshButton.prop("disabled", true).text("Refreshing...");
      isInitialized = false;
      if (dbInstance) {
        await connInstance?.close();
        await dbInstance.terminate();
      }
      dbInstance = null;
      connInstance = null;
      await initDuckDB(layout);
      const newData = lastCustomSQL 
        ? { data: await executeCustomSQL(lastCustomSQL, layout), filteredCount: 0, unmatchedCount: totalCount }
        : await fetchPage(0, pageSize, currentFilter, fieldMappings, cubeData, layout);
      lastFetchedData = newData; // Ensure the new data is cached
      justRefreshed = true; // Set the flag to indicate a refresh occurred
      $element.empty();
      await renderTable($element, newData, layout, 0, fieldMappings, cubeData, pageSize);
      qlik.resize();
    } catch (error) {
      console.error("Refresh failed:", error);
      container.append($("<div>").text(`Refresh Error: ${error.message}`));
    } finally {
      refreshButton.prop("disabled", false).text("Refresh Data");
      refreshPending = false;
    }
  });

  let addPivotButton = $("<button>").addClass("add-pivot-button").text("Add Pivot").attr({
    "aria-label": "Add another pivot field",
    "role": "button"
  }).css({
    "border": "1px solid black",
    "padding": "2px 6px",
    "cursor": "pointer",
    "background-color": "#fff",
    "color": "#000"
  }).on("click", async () => {
    if (pivotFields.filter(Boolean).length < maxPivot && pivotFields.filter(Boolean).length < availableFields.length) {
      pivotFields.push("");
      offset = 0;
      const newData = await fetchPage(0, pageSize, currentFilter, fieldMappings, cubeData, layout);
      $element.empty();
      renderTable($element, newData, layout, 0, fieldMappings, cubeData, pageSize);
    }
  });

  let clearButton = $("<button>").addClass("clear-button").text("Clear").attr({
    "aria-label": "Clear pivots and query/search",
    "role": "button"
  }).css({
    "border": "1px solid black",
    "padding": "2px 6px",
    "cursor": "pointer",
    "background-color": "#fff",
    "color": "#000"
  }).on("click", async () => {
    pivotFields = [];
    currentFilter = "";
    lastCustomSQL = "";
    offset = 0;
    sortField = null;
    sortDirection = "asc";
    $element.find(".entry-input").val("");
    const resetData = await fetchPage(0, pageSize, "", fieldMappings, cubeData, layout);
    $element.empty();
    renderTable($element, resetData, layout, 0, fieldMappings, cubeData, pageSize);
  });

  let statsButton = $("<button>").addClass("stats-button").text("Stats").attr({
    "aria-label": "Show column statistics",
    "role": "button"
  }).css({
    "border": "1px solid black",
    "padding": "2px 6px",
    "cursor": "pointer",
    "background-color": "#fff",
    "color": "#000"
  });

  let statsDropdown = $("<select>").addClass("stats-dropdown").css({ margin: "0 5px" });
  statsDropdown.append($("<option>").val("Sample").text("All Columns"));
  availableFields.forEach(field => {
    statsDropdown.append($("<option>").val(field).text(field));
  });

  statsButton.on("click", async () => {
    $element.text("Calculating stats...");
    const selectedColumn = statsDropdown.val();
    let statsData;
    if (selectedColumn === "Sample") {
      statsData = await executeStatsForSample(layout);
    } else {
      statsData = await executeStatsForColumn(selectedColumn, layout);
    }
    $element.empty();
    renderTable($element, { data: statsData, filteredCount: 0, unmatchedCount: totalCount }, layout, 0, fieldMappings, cubeData, pageSize);
  });

  buttonContainer.append(refreshButton, addPivotButton, clearButton, statsButton, statsDropdown);

  let pivotContainer = $("<div>").addClass("pivot-container").css({ margin: "0 0 10px 0", display: "flex", gap: "10px", "flex-wrap": "wrap" });
  container.append(pivotContainer);

  const createPivotSelect = (index) => {
    const $wrapper = $("<div>").addClass(`pivot-wrapper-${index}`).css({ display: "flex", gap: "5px", "align-items": "center" });
    const $label = $("<label>").text(`${index + 1}`).css({ "margin-right": "5px" });
    const $select = $("<select>").attr("id", `pivot${index}`).css({ margin: "0 5px 0 0" });
    $select.append($("<option>").val("").text(`${index + 1}`));
    const usedFields = pivotFields.filter((f, i) => f && i !== index);
    availableFields.forEach(field => {
      if (!usedFields.includes(field) || field === pivotFields[index]) {
        $select.append($("<option>").val(field).text(field).prop("selected", field === pivotFields[index]));
      }
    });

    $select.on("change", async () => {
      pivotFields[index] = $select.val();
      offset = 0;
      const newData = await fetchPage(0, pageSize, currentFilter, fieldMappings, cubeData, layout);
      $element.empty();
      renderTable($element, newData, layout, 0, fieldMappings, cubeData, pageSize);
    });

    $wrapper.append($label, $select);
    pivotContainer.append($wrapper);
    return $select;
  };

  pivotFields.forEach((_, index) => createPivotSelect(index));

  let entryInput = $("<input>").addClass("entry-input").attr({ 
    type: "text", 
    placeholder: "Search or enter SQL query" 
  }).css({ width: "100%", margin: "0 0 10px 0" });

  entryInput.off("keypress").on("keypress", async (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const input = entryInput.val().trim();
      if (input) {
        const upperInput = input.toUpperCase();
        if (upperInput.startsWith("SELECT") || 
            upperInput.startsWith("PRAGMA") || 
            upperInput.startsWith("DESCRIBE") || 
            upperInput.startsWith("SHOW") ||
            upperInput.startsWith("SUMMARIZE") || 
            upperInput.startsWith("EXPLAIN")) {
          lastCustomSQL = input;
          const result = await executeCustomSQL(input, layout);
          renderTable($element, { 
            data: result, 
            filteredCount: result.length && !result[0].error ? result.length : 0, 
            unmatchedCount: result.length && !result[0].error ? totalCount - result.length : totalCount 
          }, layout, 0, fieldMappings, cubeData, pageSize);
        } else {
          lastCustomSQL = "";
          currentFilter = input;
          offset = 0;
          const searchData = await fetchPage(0, pageSize, currentFilter, fieldMappings, cubeData, layout);
          renderTable($element, searchData, layout, 0, fieldMappings, cubeData, pageSize);
        }
      }
    }
  });

  container.append(entryInput);
  entryInput.val(lastCustomSQL || currentFilter);

  let tableContainer = $("<div>").addClass("table-container-inner").css({
    "min-height": "150px",
    "max-height": "600px",
    "max-width": "100%",
    "overflow-x": "auto",
    "overflow-y": "auto",
    border: "1px solid #ccc",
    "background-color": "#fff"
  }).attr("aria-live", "polite");
  container.append(tableContainer);

  console.log("Building table");
  const table = $("<table>").css({ "border-collapse": "collapse", width: "100%", "min-width": "2000px", "color": "#000", "background-color": "#fff" });
  const thead = $("<thead>");
  const tbody = $("<tbody>");

  let headers;
  if (data.data && data.data.length) {
    const isError = data.data.length === 1 && data.data[0].error;
    if (isError) {
      headers = ["Status"];
    } else if (activePivotFields.length > 1) {
      headers = activePivotFields.map((_, i) => `field${i + 1}`).concat(["count"]);
    } else {
      headers = Object.keys(data.data[0]);
    }
  } else {
    headers = ["Status"];
  }

  if (activePivotFields.length && sortField && !headers.includes(sortField)) {
    sortField = null;
    sortDirection = "asc";
  }

  if (data.data && data.data.length) {
    const isError = data.data.length === 1 && data.data[0].error;
    if (isError) {
      thead.append($("<tr>").append(
        $("<th>").text("Status").css({
          border: "1px solid black",
          padding: "8px",
          position: "sticky",
          top: "0",
          background: "#f5f5f5",
          "font-weight": "bold"
        })
      ));
      tbody.append($("<tr>").append(
        $("<td>").text(data.data[0].error).css({
          border: "1px solid black",
          padding: "8px",
          color: "red"
        })
      ));
    } else if (activePivotFields.length > 1) {
      thead.append($("<tr>").append(
        headers.map((header, i) => {
          const isMapped = fieldMappings.some(m => m.parquetField === (i < activePivotFields.length ? activePivotFields[i] : "count"));
          const isSelected = isMapped && cubeData[fieldMappings.find(m => m.parquetField === (i < activePivotFields.length ? activePivotFields[i] : "count"))?.qlikField]?.selected?.length > 0;
          return $("<th>").text(i < activePivotFields.length ? activePivotFields[i] : "Count").css({
            border: "1px solid black",
            padding: "8px",
            position: "sticky",
            top: "0",
            background: "#f5f5f5",
            "font-weight": isMapped ? "bold" : "normal",
            "text-decoration": isMapped ? "underline" : "none",
            "cursor": "pointer"
          }).on("click", () => {
            sortField = header;
            sortDirection = sortField === header && sortDirection === "asc" ? "desc" : "asc";
            const sortedData = { ...data, data: [...data.data].sort((a, b) => {
              let aVal = a[header] ?? "";
              let bVal = b[header] ?? "";
              if (sortField === "count" || (!isNaN(Number(aVal)) && !isNaN(Number(bVal)))) {
                aVal = Number(aVal) || 0;
                bVal = Number(bVal) || 0;
                return sortDirection === "asc" ? aVal - bVal : bVal - aVal;
              }
              aVal = String(aVal);
              bVal = String(bVal);
              return sortDirection === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(bVal);
            })};
            renderTable($element, sortedData, layout, currentOffset, fieldMappings, cubeData, pageSize);
          });
        })
      ));
      let currentLevels = new Array(activePivotFields.length).fill(null);
      data.data.forEach(row => {
        let $row = $("<tr>");
        for (let i = 0; i < activePivotFields.length; i++) {
          const fieldValue = row[`field${i + 1}`];
          if (fieldValue !== currentLevels[i]) {
            currentLevels[i] = fieldValue;
            for (let j = i + 1; j < activePivotFields.length; j++) currentLevels[j] = null;
            const $toggle = $("<span>").html("▶ ").attr("data-level", i).css({ "cursor": "pointer" }).on("click", function() {
              const $this = $(this);
              const level = parseInt($this.attr("data-level"));
              let $nextRow = $this.closest("tr").next();
              while ($nextRow.length && $nextRow.find("td").eq(level).text() === "") {
                $nextRow.toggle();
                $nextRow = $nextRow.next();
              }
              $this.html($this.html() === "▶ " ? "▼ " : "▶ ");
            });
            $row.append(
              ...Array(i).fill().map(() => $("<td>").text("").css({ border: "1px solid black", padding: "8px" })),
              $("<td>").append($toggle, fieldValue).css({ border: "1px solid black", padding: "8px" }),
              ...Array(activePivotFields.length - i - 1).fill().map(() => $("<td>").text("").css({ border: "1px solid black", padding: "8px" })),
              $("<td>").text(row[`count${i + 1}`]).css({ 
                border: "1px solid black", 
                padding: "8px",
                "font-weight": i === 0 && boldFirstPivotCount ? "bold" : "normal"
              })
            );
            tbody.append($row);
            break;
          } else if (i === activePivotFields.length - 1) {
            $row.append(
              ...Array(activePivotFields.length - 1).fill().map(() => $("<td>").text("").css({ border: "1px solid black", padding: "8px" })),
              $("<td>").text(fieldValue).css({ border: "1px solid black", padding: "8px" }),
              $("<td>").text(row[`count${activePivotFields.length}`]).css({ border: "1px solid black", padding: "8px" })
            );
            tbody.append($row);
          }
        }
      });
    } else {
      thead.append($("<tr>").append(
        headers.map(header => {
          const isMapped = fieldMappings.some(m => m.parquetField === header);
          const isSelected = isMapped && cubeData[fieldMappings.find(m => m.parquetField === header)?.qlikField]?.selected?.length > 0;
          return $("<th>").text(header).css({
            border: "1px solid black",
            padding: "8px",
            position: "sticky",
            top: "0",
            background: "#f5f5f5",
            "font-weight": isSelected ? "bold" : "normal",
            "text-decoration": isSelected ? "underline" : "none",
            "cursor": "pointer"
          }).on("click", async () => {
            sortField = header;
            sortDirection = sortField === header && sortDirection === "asc" ? "desc" : "asc";
            if (layout.sortScope === "entireTable" && activePivotFields.length === 0) {
              const sortedData = await fetchPage(currentOffset, pageSize, currentFilter, fieldMappings, cubeData, layout, sortField, sortDirection);
              renderTable($element, sortedData, layout, currentOffset, fieldMappings, cubeData, pageSize);
            } else {
              const sortedData = { ...data, data: [...data.data].sort((a, b) => {
                let aVal = a[header] ?? "";
                let bVal = b[header] ?? "";
                if (sortField === "count" || (!isNaN(Number(aVal)) && !isNaN(Number(bVal)))) {
                  aVal = Number(aVal) || 0;
                  bVal = Number(bVal) || 0;
                  return sortDirection === "asc" ? aVal - bVal : bVal - aVal;
                }
                aVal = String(aVal);
                bVal = String(bVal);
                return sortDirection === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(bVal);
              })};
              renderTable($element, sortedData, layout, currentOffset, fieldMappings, cubeData, pageSize);
            }
          });
        })
      ));
      tbody.append(
        data.data.map(row => $("<tr>").append(
          headers.map(header => $("<td>").text(row[header] ?? "").css({
            border: "1px solid black",
            padding: "8px",
            "font-weight": header === "count" && activePivotFields.length === 1 && boldFirstPivotCount ? "bold" : "normal"
          }))
        ))
      );
    }
  } else {
    thead.append($("<tr>").append(
      $("<th>").text("Status").css({
        border: "1px solid black",
        padding: "8px",
        position: "sticky",
        top: "0",
        background: "#f5f5f5",
        "font-weight": "bold"
      })
    ));
    tbody.append($("<tr>").append(
      $("<td>").text("No matching records found").css({ 
        border: "1px solid black", 
        padding: "20px", 
        "text-align": "center" 
      })
    ));
  }
  table.append(thead, tbody);
  tableContainer.append(table);

  let paginationContainer = $("<div>").addClass("pagination-container").css({
    "margin-top": "10px",
    display: "flex",
    gap: "10px"
  });
  if (!activePivotFields.length) {
    container.append(paginationContainer);

    let backButton = $("<button>").addClass("back-button").text("Back").attr({
      "aria-label": "Load previous page of records",
      "role": "button"
    }).css({
      "border": "1px solid black",
      "padding": "2px 6px",
      "cursor": "pointer",
      "background-color": "#fff",
      "color": "#000",
      "display": currentOffset > 0 ? "inline-block" : "none"
    }).on("click", async () => {
      offset = Math.max(0, offset - pageSize);
      const prevData = await fetchPage(offset, pageSize, currentFilter, fieldMappings, cubeData, layout, sortField, sortDirection);
      renderTable($element, prevData, layout, offset, fieldMappings, cubeData, pageSize);
    });

    let nextButton = $("<button>").addClass("next-button").text("Next").attr({
      "aria-label": "Load next page of records",
      "role": "button"
    }).css({
      "border": "1px solid black",
      "padding": "2px 6px",
      "cursor": "pointer",
      "background-color": "#fff",
      "color": "#000"
    }).on("click", async () => {
      offset += pageSize;
      const nextData = await fetchPage(offset, pageSize, currentFilter, fieldMappings, cubeData, layout, sortField, sortDirection);
      renderTable($element, nextData.data.length ? nextData : data, layout, 
        nextData.data.length ? offset : offset - pageSize, fieldMappings, cubeData, pageSize);
    });

    paginationContainer.append(backButton, nextButton);
  }

  let infoDiv = $("<div>").addClass("info-div").css({
    "margin-top": "10px",
    "font-size": "12px",
    color: "#666",
    "text-align": "center",
    "background-color": "#fff"
  }).html(`
    ${layout.copyrightTribute || extensionConfig.copyright.tribute}, 
    ${layout.copyrightDescription || extensionConfig.copyright.description}.<br>
    Built with ${extensionConfig.copyright.dependencies.map(dep => 
      `<a href="${dep.url}" target="_blank">${dep.name}</a>`).join(" and ")}. 
    ${layout.copyrightDisclaimer || extensionConfig.copyright.disclaimer}
  `);
  container.append(infoDiv);

  console.log("renderTable completed");
}
  async function setupCube(fieldMappings, $element, layout) {
    if (!fieldMappings || !fieldMappings.length) {
      console.log("No field mappings defined, skipping cube setup.");
      return { cube: null, initialCubeData: {} };
    }
    const cubeDef = {
      qDimensions: fieldMappings.map(mapping => ({
        qDef: { qFieldDefs: [mapping.qlikField] }
      })),
      qInitialDataFetch: [{
        qTop: 0,
        qLeft: 0,
        qWidth: fieldMappings.length,
        qHeight: 1000
      }]
    };
    if (!cube) {
      try {
        cube = await qlik.currApp().createCube(cubeDef);
        console.log("Cube created successfully.");
        const matrix = cube.layout.qHyperCube.qDataPages[0]?.qMatrix || [];
        const initialCubeData = Object.fromEntries(
          fieldMappings.map((mapping, index) => [
            mapping.qlikField,
            { all: matrix.map(row => row[index]?.qText).filter(Boolean), selected: [] }
          ])
        );
        console.log("Initial cubeData (full domain):", initialCubeData);
        cube.on("changed", async () => {
          await new Promise(resolve => setTimeout(resolve, 100));
          const matrix = cube.layout.qHyperCube.qDataPages[0]?.qMatrix || [];
          const cubeData = Object.fromEntries(
            fieldMappings.map((mapping, index) => [
              mapping.qlikField,
              {
                all: initialCubeData[mapping.qlikField].all,
                selected: matrix.map(row => row[index]?.qText).filter(Boolean)
              }
            ])
          );
          console.log("Cube changed - cubeData:", cubeData);
          lastCubeDataHash = JSON.stringify(cubeData); // Update hash on cube change
          if (!lastCustomSQL) {
            currentFilter = "";
            offset = 0;
          }
          const data = lastCustomSQL 
            ? { data: await executeCustomSQL(lastCustomSQL, layout), filteredCount: 0, unmatchedCount: totalCount }
            : await fetchPage(offset, layout.pageSize || 25, currentFilter, fieldMappings, cubeData, layout, sortField, sortDirection);
          $element.empty();
          renderTable($element, data, layout, offset, fieldMappings, cubeData, layout.pageSize || 25);
        });
        return { cube, initialCubeData };
      } catch (error) {
        console.error("Error creating cube:", error);
        return { cube: null, initialCubeData: {} };
      }
    }
    return { cube, initialCubeData: {} };
  }

  window.onbeforeunload = async () => {
    if (cube?.backendApi?.abort) cube.backendApi.abort();
    if (connInstance) await connInstance.close();
    if (dbInstance) await dbInstance.terminate();
  };

  return {
    definition: {
      type: "items",
      component: "accordion",
      items: {
        dataSource: {
          type: "items",
          label: "Data Source",
          items: {
            dataFiles: {
              type: "array",
              ref: "dataFiles",
              label: "Data Files",
              itemTitleRef: "url",
              allowAdd: true,
              allowRemove: true,
              items: {
                url: { type: "string", ref: "url", label: "File URL", defaultValue: "" },
                type: { 
                  type: "string", 
                  component: "dropdown", 
                  ref: "type", 
                  label: "File Type", 
                  options: [
                    { value: "parquet", label: "Parquet" },
                    { value: "csv", label: "CSV" },
                    { value: "json", label: "JSON" },
                    { value: "arrow", label: "Arrow" }
                  ],
                  defaultValue: "parquet"
                },
                name: { type: "string", ref: "name", label: "File Name (optional)", defaultValue: "" }
              }
            },
            showFilteredSum: { 
              type: "boolean", 
              ref: "showFilteredSum", 
              label: "Show Filtered Record Count", 
              defaultValue: true 
            }
          }
        },
        dependencies: {
          type: "items",
          label: "Dependencies",
          items: {
            duckdbWasmUrl: {
              type: "string",
              ref: "duckdbWasmUrl",
              label: "DuckDB WASM URL",
              defaultValue: ""
            },
            duckdbWorkerUrl: {
              type: "string",
              ref: "duckdbWorkerUrl",
              label: "DuckDB Worker URL",
              defaultValue: ""
            },
            arrowUrl: {
              type: "string",
              ref: "arrowUrl",
              label: "Arrow JS URL",
              defaultValue: ""
            }
          }
        },
        settings: {
          type: "items",
          label: "Settings",
          items: {
            queryTimeout: {
              type: "integer",
              ref: "queryTimeout",
              label: "Query Timeout (ms)",
              defaultValue: 60000,
              min: 1000,
              max: 120000
            },
            maxRam: {
              type: "integer",
              ref: "maxRam",
              label: "Max RAM (GB)",
              defaultValue: 4,
              min: 1,
              max: 32
            },
            debug: {
              type: "boolean",
              ref: "debug",
              label: "Enable Debug Logging",
              defaultValue: false
            },
            maxPivot: {
              type: "integer",
              ref: "maxPivot",
              label: "Max Pivot Fields",
              defaultValue: 3,
              min: 1,
              max: 10
            },
            maxQueryRows: {
              type: "integer",
              ref: "maxQueryRows",
              label: "Max Custom Query Rows (0 to disable)",
              defaultValue: 0
            },
            sortScope: {
              type: "string",
              component: "dropdown",
              ref: "sortScope",
              label: "Sort Scope",
              options: [
                { value: "selectedRecords", label: "Selected Records" },
                { value: "entireTable", label: "Entire Table" }
              ],
              defaultValue: "selectedRecords"
            },
            loadingMessage: {
              type: "string",
              ref: "loadingMessage",
              label: "Loading Message",
              defaultValue: "Enjoy this extension. During data load take a moment of reflection..."
            },
            pagination: {
              type: "items",
              label: "Pagination",
              items: {
                pageSize: { 
                  type: "integer", 
                  ref: "pageSize", 
                  label: "Rows per Page", 
                  defaultValue: 25 
                }
              }
            }
          }
        },
        appearance: {
          type: "items",
          label: "Appearance",
          items: {
            general: {
              type: "items",
              label: "General",
              items: {
                showTitles: {
                  type: "boolean",
                  ref: "showTitles",
                  label: "Show titles",
                  defaultValue: true
                },
                title: {
                  type: "string",
                  ref: "title",
                  label: "Title",
                  defaultValue: "Data Explorer",
                  expression: "optional"
                },
                subtitle: {
                  type: "string",
                  ref: "subtitle",
                  label: "Subtitle",
                  defaultValue: "",
                  expression: "optional"
                },
                footnote: {
                  type: "string",
                  ref: "footnote",
                  label: "Footnote",
                  defaultValue: "",
                  expression: "optional"
                }
              }
            },
            styles: {
              type: "items",
              label: "Styles",
              items: {
                containerPadding: { type: "string", ref: "styles.containerPadding", label: "Container Padding", defaultValue: "10px" },
                kpiMargin: { type: "string", ref: "styles.kpiMargin", label: "KPI Margin Bottom", defaultValue: "10px" },
                kpiFontWeight: { type: "string", ref: "styles.kpiFontWeight", label: "KPI Font Weight", defaultValue: "bold" },
                kpiColor: { type: "string", ref: "styles.kpiColor", label: "KPI Color", defaultValue: "#333" },
                tableMaxHeight: { type: "string", ref: "styles.tableMaxHeight", label: "Table Max Height", defaultValue: "600px" },
                tableMaxWidth: { type: "string", ref: "styles.tableMaxWidth", label: "Table Max Width", defaultValue: "100%" },
                tableBorder: { type: "string", ref: "styles.tableBorder", label: "Table Border", defaultValue: "1px solid #ccc" },
                thBorder: { type: "string", ref: "styles.thBorder", label: "Header Border", defaultValue: "1px solid black" },
                thPadding: { type: "string", ref: "styles.thPadding", label: "Header Padding", defaultValue: "8px" },
                thBackground: { type: "string", ref: "styles.thBackground", label: "Header Background", defaultValue: "#f5f5f5" },
                tdBorder: { type: "string", ref: "styles.tdBorder", label: "Cell Border", defaultValue: "1px solid black" },
                tdPadding: { type: "string", ref: "styles.tdPadding", label: "Cell Padding", defaultValue: "8px" },
                buttonMargin: { type: "string", ref: "styles.buttonMargin", label: "Button Margin Top", defaultValue: "10px" },
                buttonBorder: { type: "string", ref: "styles.buttonBorder", label: "Button Border", defaultValue: "1px solid black" },
                boldFirstPivotCount: { 
                  type: "boolean", 
                  ref: "styles.boldFirstPivotCount", 
                  label: "Bold First Pivot Count", 
                  defaultValue: true 
                }
              }
            }
          }
        },
        fieldMappings: {
          type: "array",
          ref: "fieldMappings",
          label: "Field Mappings",
          itemTitleRef: "qlikField",
          allowAdd: true,
          allowRemove: true,
          addTranslation: "Add Mapping",
          items: {
            qlikField: { type: "string", ref: "qlikField", label: "Qlik Field Name", defaultValue: "" },
            parquetField: { type: "string", ref: "parquetField", label: "Data Column Name", defaultValue: "" }
          }
        },
        copyrightSettings: {
          type: "items",
          label: "Copyright & Dedication",
          items: {
            copyrightTribute: {
              type: "string",
              ref: "copyrightTribute",
              label: "Tribute",
              defaultValue: "This Qlik Extension is shared in memory of Stuart Wannop"
            },
            copyrightDescription: {
              type: "string",
              ref: "copyrightDescription",
              label: "Description",
              defaultValue: "A Qlik Champion who would have enjoyed seeing this type of embedded object"
            },
            copyrightDisclaimer: {
              type: "string",
              ref: "copyrightDisclaimer",
              label: "Disclaimer",
              defaultValue: "Use of this extension is entirely at your own risk; no warranties are implied or inferred"
            }
          }
        }
      }
    },
    paint: async function ($element, layout) {
      const fieldMappings = layout.fieldMappings || [];
      console.log("Paint started");
      await applyThemeStyles(layout);
      $element.css({"background-color": "var(--background-color)"});

      const files = layout.dataFiles || [{ url: layout.parquetUrl, type: "parquet" }];
      const fileType = files[0]?.type?.toUpperCase() || "PARQUET";

      // Check for missing dependencies or files
      if (!layout.duckdbWasmUrl || !layout.duckdbWorkerUrl || !layout.arrowUrl) {
        $element.empty();
        const errorDiv = $("<div>").addClass("error").css({
          "background-color": "#f8d7da",
          "color": "#721c24",
          "padding": "10px"
        }).text("Error: Missing DuckDB or Arrow library URLs. Please configure them in the Dependencies section.");
        $element.append(errorDiv);
        return qlik.Promise.resolve();
      }

      if (!files.length || !files[0].url) {
        console.log("No files selected");
        $element.empty();
        const errorDiv = $("<div>").addClass("error").css({
          "background-color": "#f8d7da",
          "color": "#721c24",
          "padding": "10px"
        }).text(`Please select at least one ${fileType} file to display in the Data Source section.`);
        $element.append(errorDiv);
        return qlik.Promise.resolve();
      }

      try {
        // Compute a hash of the layout to detect changes (excluding irrelevant properties)
        const layoutHash = JSON.stringify({
          dataFiles: layout.dataFiles,
          fieldMappings: layout.fieldMappings,
          pageSize: layout.pageSize,
          maxQueryRows: layout.maxQueryRows,
          sortScope: layout.sortScope,
          maxPivot: layout.maxPivot,
          showTitles: layout.showTitles,
          title: layout.title,
          subtitle: layout.subtitle,
          footnote: layout.footnote,
          styles: layout.styles
        });

        // Check if layout or cube data has changed
        let cubeData = {};
        if (cube) {
          const matrix = cube.layout.qHyperCube.qDataPages[0]?.qMatrix || [];
          cubeData = Object.fromEntries(
            fieldMappings.map((mapping, index) => [
              mapping.qlikField,
              {
                all: cubeData[mapping.qlikField]?.all || matrix.map(row => row[index]?.qText).filter(Boolean),
                selected: matrix.map(row => row[index]?.qText).filter(Boolean)
              }
            ])
          );
        }
        const cubeDataHash = JSON.stringify(cubeData);

        const hasLayoutChanged = lastLayoutHash !== layoutHash;
        const hasCubeDataChanged = lastCubeDataHash !== cubeDataHash;
        const needsDataFetch = !lastFetchedData || hasLayoutChanged || hasCubeDataChanged;

        // If a refresh just occurred, skip the loading message and use cached data
        if (justRefreshed && lastFetchedData) {
          console.log("Recent refresh detected, skipping loading message");
          justRefreshed = false; // Reset the flag
          await renderTable($element, lastFetchedData, layout, offset, fieldMappings, cubeData, layout.pageSize || 25);
          return qlik.Promise.resolve();
        }

        // Only show loading message if we need to fetch data
        if (needsDataFetch) {
          const loadingMessage = layout.loadingMessage || "Enjoy this extension. During data load take a moment of reflection...";
          $element.empty();
          $element.text(loadingMessage);
          console.log("Loading message displayed:", loadingMessage);
        } else {
          console.log("Skipping loading message; using cached data");
        }

        // Initialize DuckDB and cube if not already done
        if (!isInitialized) {
          console.log("Initializing DuckDB");
          await initDuckDB(layout);
          console.log("DuckDB initialized, setting up cube");
          const { cube: cubeInstance, initialCubeData } = await setupCube(fieldMappings, $element, layout);
          cube = cubeInstance;
          cubeData = initialCubeData || (cubeInstance && cubeInstance.layout && cubeInstance.layout.qHyperCube && 
            cubeInstance.layout.qHyperCube.qDataPages[0] && cubeInstance.layout.qHyperCube.qDataPages[0].qMatrix
            ? Object.fromEntries(
                fieldMappings.map((mapping, index) => [
                  mapping.qlikField,
                  {
                    all: cubeInstance.layout.qHyperCube.qDataPages[0].qMatrix.map(row => row[index]?.qText).filter(Boolean),
                    selected: []
                  }
                ])
              )
            : {});
          console.log("Cube setup complete, cubeData:", cubeData);
        } else if (!cube) {
          console.log("Setting up cube (DuckDB already initialized)");
          const { cube: cubeInstance, initialCubeData } = await setupCube(fieldMappings, $element, layout);
          cube = cubeInstance;
          cubeData = initialCubeData || (cubeInstance && cubeInstance.layout && cubeInstance.layout.qHyperCube && 
            cubeInstance.layout.qHyperCube.qDataPages[0] && cubeInstance.layout.qHyperCube.qDataPages[0].qMatrix
            ? Object.fromEntries(
                fieldMappings.map((mapping, index) => [
                  mapping.qlikField,
                  {
                    all: cubeInstance.layout.qHyperCube.qDataPages[0].qMatrix.map(row => row[index]?.qText).filter(Boolean),
                    selected: []
                  }
                ])
              )
            : {});
          console.log("Cube setup complete, cubeData:", cubeData);
        } else {
          console.log("Using existing cube");
          const matrix = cube.layout.qHyperCube.qDataPages[0]?.qMatrix || [];
          cubeData = Object.fromEntries(
            fieldMappings.map((mapping, index) => [
              mapping.qlikField,
              {
                all: cubeData[mapping.qlikField]?.all || matrix.map(row => row[index]?.qText).filter(Boolean),
                selected: matrix.map(row => row[index]?.qText).filter(Boolean)
              }
            ])
          );
          console.log("Cube data refreshed, cubeData:", cubeData);
        }

        console.log("paint - fieldMappings:", fieldMappings);
        console.log("paint - cubeData:", cubeData);

        let initialData;
        if (needsDataFetch) {
          if (lastCustomSQL) {
            console.log("Executing custom SQL:", lastCustomSQL);
            initialData = { data: await executeCustomSQL(lastCustomSQL, layout), filteredCount: 0, unmatchedCount: totalCount };
            lastFetchedData = initialData;
            console.log("Custom SQL executed, initialData:", initialData);
          } else {
            console.log("Fetching new page data");
            initialData = await fetchPage(offset, layout.pageSize || 25, currentFilter, fieldMappings, cubeData, layout, sortField, sortDirection);
            lastFetchedData = initialData;
            console.log("Page data fetched, initialData:", initialData);
          }
        } else {
          console.log("Using cached data");
          initialData = lastFetchedData;
          console.log("Cached initialData:", initialData);
        }

        // Update hashes for next paint call
        lastLayoutHash = layoutHash;
        lastCubeDataHash = cubeDataHash;

        console.log("Rendering table with initialData:", initialData);
        await renderTable($element, initialData, layout, offset, fieldMappings, cubeData, layout.pageSize || 25);
        console.log("Table rendered");
        return qlik.Promise.resolve();
      } catch (error) {
        console.error("Paint error:", error);
        $element.empty();
        let errorMessage = "Error loading data.";
        if (error.message === "MISSING_DEPENDENCIES") {
          errorMessage = "Error: Missing DuckDB or Arrow library URLs. Please configure them in the Dependencies section.";
        } else if (error.message === "NO_FILES_SELECTED") {
          errorMessage = `Please select at least one ${fileType} file to display in the Data Source section.`;
        } else if (error.message === "NO_VALID_FILES_LOADED") {
          errorMessage = `No valid ${fileType} files could be loaded. Check file URLs and permissions.`;
        } else if (error.message.startsWith("FILE_TYPE_MISMATCH")) {
          errorMessage = `Error: ${error.message.split(":")[1].trim()}. Ensure the file type matches the URL extension.`;
        } else if (error.message.startsWith("FETCH_FAILED")) {
          errorMessage = `Error: Failed to fetch ${fileType} file ${error.message.split(":")[1].trim()}. Check the URL or network.`;
        } else {
          errorMessage = `Error loading ${fileType} data: ${error.message}`;
        }
        const errorDiv = $("<div>").addClass("error").css({
          "background-color": "#f8d7da",
          "color": "#721c24",
          "padding": "10px"
        }).text(errorMessage);
        $element.append(errorDiv);
        return qlik.Promise.reject(error);
      }
    }
  };
});